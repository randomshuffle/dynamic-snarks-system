# Dynamic SNARK system

Rust implementation of the dynamic SNARK compiler from Section 4 of the
neighboring `dhbs` paper.

For the reproducible 2^24-gate BN254 experiment with 64-way initial WHIR
interleaving, see the [EC2 benchmark guide](docs/ec2-2p24-experiment.md).

## Instantiation

- BN254 scalar field (`p3-bn254`), with a two-adic subgroup suitable for FFTs.
- Width-three Poseidon2 with a one-field-element, 32-byte digest and the
  Plonky3 BN254 128-bit parameter schedule (8 full and 56 partial rounds).
- The original HyperPlonk PIOP decomposition: a gate ZeroCheck and a wiring
  PermCheck reduced through ProductCheck and ZeroCheck to Fiat--Shamir
  sumchecks.
- Plonky3 WHIR at a configured 127-bit security target, folding factor four
  (16 field elements per queried leaf), rate-one-half Reed--Solomon codewords,
  and native BLAKE3 Merkle hashing and Fiat--Shamir for every polynomial
  commitment and arbitrary-point opening.
- Position-bound Poseidon2 Merkle vector commitments for the Section 4 dynamic
  compiler.
- A Poseidon-specific commit-all-intermediate-rounds (CAIR) proof for the
  initial full-tree Merkle computation. Its terminal claims share one batched
  WHIR opening and are linked to the static proof's main commitment. Columns
  evaluated at the same row point are authenticated by one randomized tensor
  opening rather than one PCS claim per column.
- A sparse-DAG CAIR proof for each transition. Transitions have no dense
  Plonkish trace or per-level key.

CAIR places every Merkle hash in a 1-indexed binary-heap row. Its 64-column
scalar trace commits the first coordinate at all 57 partial-round boundaries,
the two missing coordinates at both ends, two hash-input coordinates, and the
digest. An exact degree-five Cayley--Hamilton recurrence checks all 56 partial
rounds in one degree-six ZeroCheck. Four batched full-round reductions check
the two four-round caps without committing their intermediate states. A
degree-three sumcheck checks both child routes, leaf values, the
non-power-of-two leaf range, indices, and level domains. The verifier opens the
two child evaluations and the public root rather than scanning any row.

The static prover uses one row per actual gate rather than compiling copy
constraints or output comparisons into extra rows. Gate correctness is a
ZeroCheck. Wiring correctness is HyperPlonk's multiset PermCheck: one
`2N`-evaluation product oracle is constrained by a ZeroCheck and opened at its
root. Initialization and the ordinary baseline both use four columns: two
gate inputs, one gate output, and a public-input occurrence or zero. The
assignment Merkle tree commits directly to this row-major table. CAIR's
leaf-value claim is therefore one opening of the same main polynomial,
without a duplicate assignment view. All CAIR terminal claims use one WHIR
opening. Fiat--Shamir queries hash only commitments, public statement data,
and length-delimited raw sumcheck messages; earlier challenge outputs are
recomputed rather than reabsorbed.

Both arithmetic relations now have the same padded gate-row count `N` and
commit `4N` witness fields (`W`) and `4N` preprocessing fields (`P`). Public
inputs occupy column three, so the baseline adds no public-input rows. `P`
contains the original wiring conjugated by the logical-to-physical leaf map;
unused positions are fixed points. Gate selectors, zero-padding masks, and
identity labels are public formulas, and each preprocessing opening has four
claims. General gate programs retain committed local selectors/constants.
The original `2N` HyperPlonk product oracle is retained.

The update API still uses logical assignment indices. Assignment and wiring
trees, sparse transition constraints, and public-input openings all translate
them to physical leaf addresses. The sparse update main width remains 128 for
the benchmarked shapes; its row count depends on the resulting authentication
paths. See [the exact tables and polynomial oracles](docs/aligned-oracles.md).
This changes the static/transition transcripts and vector-commitment encoding;
keys, roots, and proofs must be regenerated.

The current CAIR implementation retains the committed tables and folded
sumcheck tables in memory. Disk-backed column streaming is a follow-up
engineering optimization; it does not change the proof object or verifier.

The dynamic prover maintains the paper's `ceil(log2(m + 1))` update tables.
Each transition privately commits one compact sparse-row table containing a
paired old/new assignment DAG, an indexed-permutation DAG, a new-assignment
neighbor DAG, update links, and affected gate triples. The old/new hashes are
packed into the same 64-column scalar Poseidon trace over a domain twice as
large as the sparse-row domain; one auxiliary column binds their sparse-row
domain input. The packed main width is 128 rather than 256 for the benchmarked
shapes. Row-batched sumchecks check the local relation, partial-round
recurrence, and full-round reductions. Routing tuples are algebraically
derived from the committed sparse row, so they require no duplicate columns.
After the main commitment is
fixed, Fiat--Shamir derives the routing compression challenges and the prover
makes a small second commitment to all product-tree rounds. A third sumcheck
checks tuple compression and the entire product tree. Each commitment has one
batched WHIR opening. This two-phase ordering avoids committing to product
values before their Fiat--Shamir challenges exist. The verifier key retains
only `(n, n0, m)` and the fixed
permutation commitment. Public inputs are checked with a final Merkle
multiproof.

Execution is sequential by default. Polynomial loops are expressed as
independent column/row maps, and `--features parallel` enables the custom
Poseidon sumcheck pair reduction and the Plonky3/WHIR parallel backends.
The degree-six Poseidon messages use the dyadic points
`{0, 1, -1, 2, -2, 1/2, -1/2}`. Their seven affine values are fused per row
pair, and all seven fifth powers are derived together. The scalar recurrence
reuses each partial-round fifth power across its neighboring constraints.
Each folded table is halved in place for the next linear-time sumcheck round.

`dynamic::index` preprocesses only the initial relation. The compatibility
functions `preprocess_update_sizes` and `preprocess_all_levels` perform no
transition setup because sparse CAIR tables are derived from each update.

## Minimal use

```rust
use dynamic_snarks_system::{Field, circuit::Circuit, dynamic};
use p3_field::PrimeCharacteristicRing;

let circuit = Circuit::new(1, 1, (0..7).collect())?;
let assignment = [1, 2, 3, 3, 4, 12, 9]
    .map(Field::from_u64)
    .to_vec();
let (pk, vk) = dynamic::index(circuit)?;
let state = dynamic::initialize(&pk, assignment)?;
dynamic::verify(&vk, &[Field::from_u64(9)], state.proof())?;
# Ok::<(), dynamic::Error>(())
```

Updates are sorted `(position, value)` pairs. Updates touching a gate must
contain its complete three-wire tuple, as required by Section 4.

## Tests

```text
cargo test --offline
cargo check --features parallel --offline
```

The test profile enables optimized field arithmetic while retaining debug
assertions. The end-to-end test performs real Poseidon2-in-circuit and WHIR
proofs, so it takes substantially longer than ordinary unit tests.

## Benchmark

The end-to-end benchmark compares a dynamic update with an ordinary
from-scratch HyperPlonk-style proof of the updated arithmetic circuit. The
baseline binds the public inputs in column three and contains no Merkle
commitment or CAIR proof. Both the dynamic and baseline proving keys are
preprocessed before the timers. By default the original HyperPlonk circuit has
exactly `2^14` arithmetic-gate rows. Internally the synthetic benchmark pairs
half addition rows with half multiplication rows. It uses `2^8` public inputs,
changes `2^4` arithmetic gates, and reports both the first-update
latency and the average over ten revisions. Each revision samples a fresh
uniform gate subset without replacement, using seed `20260909` and identity
wiring:

```text
cargo bench --bench dynamic_snark --features parallel
```

Initial indexing happens before the timers; transitions require no
update-dependent preprocessing. By default the benchmark starts from a
trusted base commitment without materializing the initial proof;
`DYNAMIC_SNARK_TIME_FULL_INITIAL=1` generates, verifies, and separately times
the complete initial proof. Before allocating a proving key, the benchmark
prints the exact first-update sparse shape and a conservative bound obtained
from the final composed hierarchy supports. This also covers earlier
transitions merged into those supports. Unsafe cases are skipped
unless `DYNAMIC_SNARK_FORCE=1` is set. The output also prints the original
trace, the reduced initial relation trace, and the number of Poseidon
permutations in each sparse transition DAG. Each
changed arithmetic gate contributes its complete three-position wire tuple,
including its unchanged right input. Left inputs vary deterministically by
gate and revision, with outputs recomputed to satisfy the gate. Randomness
affects the selected positions. `DYNAMIC_SNARK_UPDATE_PATTERN=contiguous`
restores the old repeated-prefix workload; `random` is the default.
`DYNAMIC_SNARK_SEED` selects the RNG seed. Workloads are generated outside the
timers and their position fingerprints are logged; retain `Cargo.lock` when
reproducing the seeded `StdRng` stream. Environment
variables `DYNAMIC_SNARK_TRACE_LOG`, `DYNAMIC_SNARK_UPDATE_LOGS`, and
`DYNAMIC_SNARK_SEQUENCE_LEN` select smaller smoke-test configurations;
`DYNAMIC_SNARK_PREFLIGHT_ONLY=1` prints resource estimates without proving. The
benchmark skips a case when a projected RAM peak exceeds 70% of physical
memory;
`DYNAMIC_SNARK_FORCE=1` overrides this safety check.
`DYNAMIC_SNARK_UPDATE_ONLY=1` skips baseline setup/proving and suppresses the
full initial proof, using the trusted-base transition harness. Each updated
state is verified outside its timer. Logs include each revision's time,
cumulative distinct positions, and the actual composed transition's size,
hierarchy level, and oracle dimensions. Empty baseline CSV fields mean that
baseline proving was skipped.

```sh
DYNAMIC_SNARK_UPDATE_ONLY=1 DYNAMIC_SNARK_UPDATE_PATTERN=random \
DYNAMIC_SNARK_SEED=20260909 RAYON_NUM_THREADS=8 \
cargo bench --offline --bench dynamic_snark --features parallel
```

See [the random-update measurements](benchmark-results/random-updates.md) for
fresh random gate sets and [the aligned-layout benchmark results](benchmark-results/aligned-comparison.md)
for the previous repeated-contiguous workload and layout comparison.

For repeated first updates from an empty hierarchy, use the `first_update`
example with `DYNAMIC_SNARK_TRACE_LOG=16`, `DYNAMIC_SNARK_FIRST_KIND=leaf`
(or `gate`), and `DYNAMIC_SNARK_FIRST_SAMPLES=30`. Column-aware PCS evaluation
and shared-row equality weights reduce the measured single-leaf median from
122.5 ms to 77.7 ms with eight Rayon threads. See the
[matched comparison and reproduction commands](benchmark-results/opening-opts.md).

The native hash microbenchmark compares one parameter-reused BN254 Poseidon2
permutation with SHA3-256 and BLAKE3 over the same prebuilt 72-byte logical
inputs. Each timed sample averages 100 hashes:

```text
cargo bench --bench hash_microbench
```

The standalone WHIR microbenchmark commits a deterministic random
`2^18`-entry multilinear polynomial and opens it at one arbitrary point. It
sweeps folding factors 1, 2, 3, and 4 (Merkle leaf widths 2, 4, 8, and 16),
comparing fixed rate `1/2` with Plonky3's default WHIR rate reduction at each
factor. Both start at `1/2` and use the same 127-bit capacity-bound security
target and zero PoW. The default schedule halves the RS domain each round;
at factor four its code rates become `1/2, 1/16, 1/128, ...`. Production
continues to use fixed rate `1/2`.

Each arm has one warmup followed by five measured samples with alternating
arm order. All proofs are verified and their claimed evaluations compared.
The benchmark reports medians for commitment, point evaluation, proximity
proof generation, total opening, total prover (commitment plus opening), and
verification. It also counts the complete cryptographic proof payload:
32 bytes per BN254 field element or BLAKE3 digest, including every Merkle
path, intermediate commitment, OOD answer, sumcheck message, stored PoW
witness, and final-polynomial element. Container lengths and encoding tags
are excluded; the initial commitment's 32 bytes are reported separately.

```text
WHIR_MICROBENCH_FACTORS=4 RAYON_NUM_THREADS=8 \
  cargo bench --offline --bench whir_microbench --features parallel
```

`WHIR_MICROBENCH_LOG_SIZE`, `WHIR_MICROBENCH_FACTORS`,
`WHIR_MICROBENCH_SAMPLES`, `WHIR_MICROBENCH_WARMUPS`,
`WHIR_MICROBENCH_CLAIMS`, `WHIR_MICROBENCH_RATE_SCHEDULES` (`fixed,default`),
and `WHIR_MICROBENCH_FRESH_INSTANCE` override the defaults. Configuration
and polynomial construction/cloning are excluded from timers. FFT twiddles
are cached process-wide even when fresh instances are requested.
`WHIR_MICROBENCH_CSV` writes raw per-sample measurements to the specified
file. See [the rate-schedule A/B results](benchmark-results/whir-rate-ab.md)
for measurements and reproduction commands.

## Dependency compatibility

Plonky3 0.6.2 uses one unstable `MaybeUninit` helper in `p3-util` on stable
Rust 1.92. This repository vendors that crate and replaces only that call with
the equivalent stable `from_raw_parts` operation; all protocol crates remain
pinned to 0.6.2.
