//! Compact partial trees and a separate small update/gate table.
use super::*;
use p3_field::Field;

pub(crate) const NODE_COLUMNS: usize = 14;
pub(crate) const NODE_WIDTH: usize = 16;
// Degree-four type indicators times the tree-id cubic, then the equality factor.
pub(crate) const NODE_DEGREE: usize = 8;
// Node tuples have degree five; auxiliary tuples degree three. Multiplying
// their shifted factors gives degree eight, then the equality factor adds one.
pub(crate) const ROUTE_DEGREE: usize = 9;

pub(crate) struct Witness {
    pub(crate) nodes: Vec<Vec<Bn254>>,
    pub(crate) updates: Vec<Vec<Bn254>>,
    pub(crate) hash_inputs: [Vec<Bn254>; 4],
    pub(crate) update_count: usize,
    pub(crate) gate_count: usize,
}

pub(crate) fn auxiliary_columns(statement: Statement) -> usize {
    compact_column_count(statement) - level_bit_count(statement)
}

pub(crate) fn auxiliary_degree(statement: Statement) -> usize {
    let range_degree = |width, bound| {
        if bound == 0 || bound == 1usize << width {
            0
        } else {
            width
        }
    };
    6.max(range_degree(pair_bit_count(statement), statement.gate_pairs) + 3)
        .max(range_degree(public_bit_count(statement), statement.public_inputs) + 3)
}

impl TransitionTable {
    pub(crate) fn packed_witness(&self) -> Witness {
        let mut node_rows = self
            .rows
            .iter()
            .filter(|r| r.node.active)
            .collect::<Vec<_>>();
        node_rows.sort_by_key(|r| !r.node.root);
        let auxiliary = self
            .rows
            .iter()
            .filter(|r| r.link.active || r.gate.active)
            .collect::<Vec<_>>();
        let update_count = auxiliary.iter().filter(|r| r.link.active).count();
        let gate_count = auxiliary.len() - update_count;
        let auxiliary_rows = auxiliary.len().max(2).next_power_of_two();
        let rows = node_rows
            .len()
            .max(auxiliary_rows)
            .max(4)
            .next_power_of_two();
        let mut nodes = vec![vec![Bn254::ZERO; rows]; NODE_COLUMNS];
        let mut hash_inputs = std::array::from_fn(|_| vec![Bn254::ZERO; 2 * rows]);
        static DUMMY: std::sync::OnceLock<[Bn254; 4]> = std::sync::OnceLock::new();
        let dummy = *DUMMY.get_or_init(dummy_hash);
        for row in 0..rows {
            let mut values = [Bn254::ZERO; NODE_COLUMNS];
            values[..4].copy_from_slice(&dummy);
            values[4..8].copy_from_slice(&dummy);
            if let Some(source) = node_rows.get(row) {
                for side in 0..2 {
                    values[4 * side..4 * side + 4].copy_from_slice(&source.hashes[side]);
                }
                values[8] = Bn254::from_u64(if source.node.root {
                    4
                } else if source.node.kind[0] {
                    1
                } else if source.node.kind[1] {
                    2
                } else {
                    3
                });
                values[9] =
                    Bn254::from_usize(source.node.tree.iter().position(|&x| x).unwrap() + 1);
                values[10] = Bn254::from_usize(source.node.level);
                values[11] = Bn254::from_usize(
                    (1usize << (self.statement.height - source.node.level)) + source.node.index,
                );
                if source.node.kind[1] {
                    values[12] = source.node.digest[0];
                    values[13] = source.node.digest[1];
                } else if source.node.kind[2] {
                    values[12] = values[10].inverse();
                }
            }
            for column in 0..NODE_COLUMNS {
                nodes[column][row] = values[column];
            }
            for word in 0..4 {
                hash_inputs[word][2 * row] = values[word];
                hash_inputs[word][2 * row + 1] = values[4 + word];
            }
        }
        let mut updates =
            vec![vec![Bn254::ZERO; auxiliary_rows]; auxiliary_columns(self.statement)];
        for (row, source) in auxiliary.iter().enumerate() {
            for (column, value) in compact_row(source, self.statement)
                .into_iter()
                .take(updates.len())
                .enumerate()
            {
                updates[column][row] = value;
            }
        }
        Witness {
            nodes,
            updates,
            hash_inputs,
            update_count,
            gate_count,
        }
    }
}

pub(crate) fn type_selectors(tau: Bn254) -> [Bn254; 5] {
    // Denominators are 24,-6,4,-6,24; inverses are constants.
    static INV: std::sync::OnceLock<[Bn254; 5]> = std::sync::OnceLock::new();
    let inv = INV.get_or_init(|| {
        [
            Bn254::from_u64(24).inverse(),
            -Bn254::from_u64(6).inverse(),
            Bn254::from_u64(4).inverse(),
            -Bn254::from_u64(6).inverse(),
            Bn254::from_u64(24).inverse(),
        ]
    });
    std::array::from_fn(|kind| {
        (0..5)
            .filter(|&i| i != kind)
            .fold(inv[kind], |p, i| p * (tau - Bn254::from_usize(i)))
    })
}

pub(crate) fn node_residuals(
    values: &[Bn254],
    roots: &[Bn254],
    statement: Statement,
) -> Vec<Bn254> {
    let [pad, leaf, boundary, internal, root] = type_selectors(values[8]);
    let tree = values[9];
    let ell = values[10];
    let heap = values[11];
    let active = Bn254::ONE - pad;
    let computed = internal + root;
    let mut residuals = vec![
        (0..5).fold(Bn254::ONE, |p, i| p * (values[8] - Bn254::from_usize(i))),
        active * (tree - Bn254::ONE) * (tree - Bn254::TWO) * (tree - Bn254::from_u64(3)),
        root - roots.iter().copied().sum::<Bn254>(),
        root * (ell - Bn254::from_usize(statement.height)),
        root * (heap - Bn254::ONE),
        leaf * ell,
        computed * (ell * values[12] - Bn254::ONE),
        computed * values[13],
        leaf * values[12],
        leaf * values[13],
        boundary * (values[12] - values[13]),
    ];
    let root_digests = [
        [statement.old_assignment.root, statement.new_assignment.root],
        [statement.permutation.root; 2],
        [statement.new_assignment.root; 2],
    ];
    for (tree_index, &selector) in roots.iter().enumerate() {
        residuals.push(selector * (tree - Bn254::from_usize(tree_index + 1)));
        for side in 0..2 {
            residuals.push(selector * (values[4 * side + 3] - root_digests[tree_index][side]));
        }
    }
    static DUMMY: std::sync::OnceLock<[Bn254; 4]> = std::sync::OnceLock::new();
    let dummy = *DUMMY.get_or_init(dummy_hash);
    for side in 0..2 {
        let hash = &values[4 * side..4 * side + 4];
        residuals.push(leaf * (hash[1] - heap + Bn254::from_usize(1 << statement.height)));
        residuals.push(leaf * (hash[2] - Bn254::ONE));
        residuals.push(computed * (hash[2] - ell - Bn254::ONE));
        for word in 0..4 {
            residuals.push((pad + boundary) * (hash[word] - dummy[word]));
        }
    }
    for word in 0..4 {
        residuals.push(active * (tree - Bn254::ONE) * (values[word] - values[4 + word]));
    }
    residuals
}

pub(crate) fn auxiliary_residuals(
    values: &[Bn254],
    selectors: &[Bn254],
    statement: Statement,
) -> Vec<Bn254> {
    let mut extended = values.to_vec();
    extended.resize(compact_column_count(statement), Bn254::ZERO);
    let mut residuals = compact_residuals(&extended, &[Bn254::ZERO; 8], statement);
    residuals.extend([
        values[0],
        values[1] - selectors[0],
        values[2] - selectors[1],
    ]);
    residuals
}

pub(crate) fn node_routes(v: &[Bn254], statement: Statement) -> Vec<Bn254> {
    let [_pad, leaf, boundary, internal, root] = type_selectors(v[8]);
    let nonroot = leaf + boundary + internal;
    let computed_nonroot = leaf + internal;
    let branch = internal + root;
    let tree = v[9];
    let ell = v[10];
    let heap = v[11];
    let position = heap - Bn254::from_usize(1 << statement.height);
    let mut routes = vec![Bn254::ZERO; 48];
    routes[..6].copy_from_slice(&[
        nonroot,
        nonroot * tree,
        nonroot * ell,
        nonroot * heap,
        computed_nonroot * v[3] + boundary * v[12],
        computed_nonroot * v[7] + boundary * v[13],
    ]);
    routes[6..12].copy_from_slice(&[
        leaf * (Bn254::from_u64(10) + tree),
        leaf * position,
        leaf * v[0],
        leaf * v[4],
        leaf * v[3],
        leaf * v[7],
    ]);
    for child in 0..2 {
        let tuple = [
            Bn254::ONE,
            tree,
            ell - Bn254::ONE,
            Bn254::TWO * heap + Bn254::from_usize(child),
            v[child],
            v[4 + child],
        ];
        for field in 0..6 {
            routes[24 + 6 * child + field] = branch * tuple[field];
        }
    }
    routes
}

pub(crate) fn auxiliary_routes(values: &[Bn254], statement: Statement) -> Vec<Bn254> {
    let mut extended = values.to_vec();
    extended.resize(compact_column_count(statement), Bn254::ZERO);
    compact_route_values(&extended, statement)
}

pub(crate) fn estimate_shape(
    circuit: &Circuit,
    indices: &[usize],
) -> Result<(usize, usize, usize), Error> {
    let (_, _, hashes) = super::estimate_endpoint_shape(circuit, indices)?;
    let mut physical = indices
        .iter()
        .map(|&i| circuit.assignment_leaf_index(i))
        .collect::<Vec<_>>();
    physical.sort_unstable();
    let mut neighbors = indices
        .iter()
        .map(|&i| circuit.assignment_leaf_index(circuit.permutation[i]))
        .collect::<Vec<_>>();
    neighbors.sort_unstable();
    let nodes = 2 * SparseMerkleDag::shape(circuit.assignment_tree_len(), &physical)?.0
        + SparseMerkleDag::shape(circuit.assignment_tree_len(), &neighbors)?.0;
    let gates = indices
        .iter()
        .copied()
        .filter(|&i| i < 6 * circuit.n)
        .map(|i| i - i % 3)
        .collect::<BTreeSet<_>>()
        .len();
    Ok((
        nodes
            .max((indices.len() + gates).max(2).next_power_of_two())
            .max(4)
            .next_power_of_two(),
        NODE_WIDTH,
        hashes,
    ))
}
