
use std::sync::OnceLock;
use std::time::Instant;

pub(crate) fn enabled() -> bool {
    static ENABLED: OnceLock<bool> = OnceLock::new();
    *ENABLED.get_or_init(|| std::env::var_os("DYNAMIC_SNARK_PROFILE_DETAIL").is_some())
}

pub(crate) struct Timer {
    component: &'static str,
    context: String,
    started: Option<Instant>,
}
impl Timer {
    pub(crate) fn new(component: &'static str, context: String) -> Self {
        Self { component, context, started: enabled().then(Instant::now) }
    }
    pub(crate) fn mark(&mut self, phase: &str) {
        if let Some(started) = self.started {
            let elapsed = started.elapsed().as_secs_f64() * 1000.0;
            std::eprintln!("detail,{},{},o{}:{},{:.6}", self.component, phase, OPENING.with(|slot| slot.get()), self.context, elapsed);
            self.started = Some(Instant::now());
        }
    }
}

std::thread_local! { static OPENING: std::cell::Cell<usize> = const { std::cell::Cell::new(0) }; }
pub struct Scope(usize);
impl Scope {
    pub fn opening(variables: usize) -> Self { Self(OPENING.with(|slot| slot.replace(variables))) }
}
impl Drop for Scope {
    fn drop(&mut self) { OPENING.with(|slot| slot.set(self.0)); }
}
